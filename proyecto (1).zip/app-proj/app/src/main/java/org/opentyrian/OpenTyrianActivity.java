package org.opentyrian;

import android.content.res.AssetManager;
import android.os.Bundle;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.libsdl.app.SDLActivity;

public class OpenTyrianActivity extends SDLActivity {
    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try { installData(); } catch (Exception e) { e.printStackTrace(); }
        super.onCreate(savedInstanceState);
    }

    // Copia los datos de Tyrian (assets/data) al almacenamiento de la app la primera vez.
    private void installData() throws Exception {
        File ext = getExternalFilesDir(null);
        if (ext == null) return;
        File dir = new File(ext, "data");
        if (new File(dir, "tyrian1.lvl").exists()) return;
        AssetManager am = getAssets();
        String[] names = am.list("data");
        if (names == null || names.length == 0) return;
        dir.mkdirs();
        byte[] buf = new byte[65536];
        for (String n : names) {
            try (InputStream in = am.open("data/" + n);
                 OutputStream out = new FileOutputStream(new File(dir, n))) {
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
        }
    }
}
